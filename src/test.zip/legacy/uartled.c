    int fd_uart = k_sys_open("/dev/uart0", 0);
    if (fd_uart < 0) {
        k_uart_puts_P(PSTR("[User Process 2] [Error] Khong the mo UART qua VFS!\n"));
        while(1);
    }
    const char *msg2 = "[User Process 2] Da khoi dong thanh cong\n";
    k_sys_write(fd_uart, msg2, strlen(msg2));
    
    while (1) {
        PORTB ^= (1 << PB0);
        k_sys_sleep(20);
    }
