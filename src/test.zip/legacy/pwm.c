void init_process(void) {
    int fd_ec0 = k_sys_open("/dev/ec0", 0); 
    int fd_ec1 = k_sys_open("/dev/ec1", 0); 
    if (fd_ec0 < 0 || fd_ec1 < 0) {
        k_uart_puts_safe("[Test PWM] Lỗi: Không thể mở Node /dev/ec0 hoặc /dev/ec1!\n");
        while(1);
    }
    k_sys_ioctl(fd_ec0, IOCTL_PWM_INIT, 0);
    k_sys_ioctl(fd_ec1, IOCTL_PWM_INIT, 0);
    
    k_uart_puts_safe("[Test PWM] Đã kích hoạt luồng băm xung độc lập cho Chân 10 và Chân 11...\n");

    uint8_t duty_led = 0;
    int8_t direction = 1; 

    char buf_ec0[1];
    char buf_ec1[2];

    while (1) {
        buf_ec0[0] = duty_led;
        k_sys_write(fd_ec0, buf_ec0, 1);
        buf_ec1[0] = duty_led; 
        buf_ec1[1] = duty_led; 
        k_sys_write(fd_ec1, buf_ec1, 2);
        duty_led += direction;
        if (duty_led == 255) {
            direction = -1;
        } else if (duty_led == 0) {
            direction = 1;
        }

        k_sys_sleep(2); 
    }
}

void user_process2(void) {
    k_sys_exit();
}

void user_process3(void) {
    int uart_fd = k_sys_open("/dev/uart0", 0);
    int servo_fd = k_sys_open("/dev/avrservo0", 0);
    if (uart_fd < 0) {
        k_uart_puts_P(PSTR("[User Process 3] [Error] Khong the mo UART qua VFS!\n"));
        while(1);
    }
    const char *msg3 = "[User Process 3] Servo da duoc dieu khien\n";
    k_sys_write(uart_fd, msg3, strlen(msg3));
    while (1) {
        k_sys_ioctl(servo_fd, IOCTL_SERVO_SET_ANGLE, 0);
        k_sys_sleep(100);
        k_sys_ioctl(servo_fd, IOCTL_SERVO_SET_ANGLE, 90);
        k_sys_sleep(100);
    }
    k_sys_sleep(30);
}
