
void init_process(void) {
        int fd_portb = k_sys_open("/dev/portb", 0);
    if (fd_portb < 0) {
        k_uart_puts_P(PSTR("[Init] [Error] Không thể mở Node /dev/portb!\n"));
        while(1) { TCNT0 = 0xFF; }
    }
    uint8_t target_pin = PIN_5; 
    int res = k_sys_ioctl(fd_portb, IOCTL_GPIO_REQUEST_PIN, target_pin);
    if (res < 0) {
        k_uart_puts_P(PSTR("[Init] [Error] Chân yêu cầu bận hoặc bị cấm!\n"));
        k_sys_close(fd_portb);
        while(1) { TCNT0 = 0xFF; }
    }

    k_sys_ioctl(fd_portb, IOCTL_GPIO_SET_DIR_OUT, target_pin);
    k_uart_puts_P(PSTR("[Init] Đã cấu hình chân mới làm OUTPUT.\n"));

    char buf_gpio[2];          
    buf_gpio[0] = target_pin;
    uint8_t led_state = 0;

    while (1) {
        led_state = !led_state;
        buf_gpio[1] = led_state; 
        k_sys_write(fd_portb, buf_gpio, 2); 

        if (led_state) {
            k_uart_puts_P(PSTR("[Init] Chân mục tiêu -> HIGH\n"));
        } else {
            k_uart_puts_P(PSTR("[Init] Chân mục tiêu -> LOW\n"));
        }

        k_sys_sleep(50); 
    }
}

void user_process2(void) {
    k_sys_exit();
}

void user_process3(void) {
    k_sys_exit();
}
