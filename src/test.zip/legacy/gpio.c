void init_process(void) {
    // --- 🚀 BƯỚC 1: MỞ NODE THIẾT BỊ PORTB (Sửa log cho chuẩn) ---
    int fd_portb = k_sys_open("/dev/portb", 0);
    if (fd_portb < 0) {
        k_uart_puts_P(PSTR("[Init] [Error] Không thể mở Node /dev/portb!\n"));
        while(1) { TCNT0 = 0xFF; }
    }
    k_uart_puts_P(PSTR("[Init] Đã mở thành công Node /dev/portb để cấu hình HC-SR04.\n"));

    uint8_t trig_pin = PIN_5; // Chân 13 trên Arduino Uno (PORTB)
    uint8_t echo_pin = PIN_4; // Chân 12 trên Arduino Uno (PORTB)

    // --- 🚀 BƯỚC 2: ĐĂNG KÝ VÀ CẤU HÌNH HƯỚNG CHÂN ---
    k_sys_ioctl(fd_portb, IOCTL_GPIO_REQUEST_PIN, trig_pin);
    k_sys_ioctl(fd_portb, IOCTL_GPIO_REQUEST_PIN, echo_pin);

    k_sys_ioctl(fd_portb, IOCTL_GPIO_SET_DIR_OUT, trig_pin); 
    k_sys_ioctl(fd_portb, IOCTL_GPIO_SET_DIR_IN, echo_pin);   

    k_uart_puts_P(PSTR("[Init] Đã cấu hình Trig (D13) làm OUTPUT, Echo (D12) làm INPUT.\n"));

    char buf_write[2];
    char buf_read[2];

    uint32_t duration;
    uint16_t distance;

    k_uart_puts_P(PSTR("[Init] Bắt đầu đo khoảng cách siêu âm...\n"));

    while (1) {
        // --- 🛠️ BƯỚC KHÓA CỐT LÕI: CHỜ CẢM BIẾN "XẢ BĂNG" (ĐỢI ECHO VỀ LOW) ---
        uint16_t anti_lockup = 2000;
        while (anti_lockup > 0) {
            buf_read[0] = echo_pin;
            k_sys_read(fd_portb, buf_read, 2);
            if (buf_read[1] == 0) break; // Nếu Echo đã về LOW thì an toàn, thoát ra để kích Trig
            
            _delay_us(5);
            anti_lockup--;
        }

        // --- BƯỚC 3: PHÁT XUNG KÍCH TRIG ---
        buf_write[0] = trig_pin; buf_write[1] = 0;
        k_sys_write(fd_portb, buf_write, 2);
        _delay_us(5); // Tăng thời gian chờ tĩnh cho ổn định áp
        
        buf_write[1] = 1;
        k_sys_write(fd_portb, buf_write, 2);
        _delay_us(10); 
        
        buf_write[1] = 0;
        k_sys_write(fd_portb, buf_write, 2);

        // --- BƯỚC 4: ĐO THỜI GIAN CHỜ VÀ ĐẾM XUNG ECHO ---
        duration = 0;
        uint32_t timeout = 40000; // 40k là đủ lớn

        // Chờ chân Echo lên HIGH
        while (timeout > 0) {
            buf_read[0] = echo_pin;
            k_sys_read(fd_portb, buf_read, 2);
            if (buf_read[1] == 1) break;
            timeout--;
        }

        // Nếu bắt được xung HIGH, tiến hành đếm thời gian phản xạ
        if (timeout > 0) {
            timeout = 40000; 
            while (timeout > 0) {
                buf_read[0] = echo_pin;
                k_sys_read(fd_portb, buf_read, 2); 
                
                if (buf_read[1] == 0) break; // Sóng đã dội về xong!
                
                duration++; 
                _delay_us(1); 
                timeout--;
            }

            distance = duration / 12; 

            if (distance > 0 && distance < 400) {
                k_uart_puts_P(PSTR("[HC-SR04] Khoảng cách: "));
                for(uint16_t i = 0; i < distance && i < 25; i++) {
                    k_uart_puts_P(PSTR("="));
                }
                k_uart_puts_P(PSTR("> \n"));
            }
        } else {
            k_uart_puts_P(PSTR("[HC-SR04] Timeout! Không phản hồi.\n"));
        }

        // TĂNG LÊN 250 TICKS: Để con HC-SR04 có đủ thời gian "thở" 
        // và xả hết sóng âm vang trong phòng, tránh bị tự nhiễu chính nó
        k_sys_sleep(250); 
    }
}

void user_process2(void) {
    k_sys_exit();
}

void user_process3(void) {
    k_sys_exit();
}
