const char msg_start[]   PROGMEM = "\n--- STARTING VFS /dev/null TEST ---\n";
const char msg_err_op[]  PROGMEM = "[TEST LỖI]: Không thể open /dev/null!\n";
const char msg_succ_op[] PROGMEM = "[SUCCESS]: Da open thành công /dev/null.\n";
const char msg_succ_wr[] PROGMEM = "[SUCCESS]: Chiều WRITE OK! Ho đen da nuot chung du lieu mượt mà.\n";
const char msg_fail_wr[] PROGMEM = "[FAILED]: Chiều WRITE LỖI! Kiểu gì Task cũng sắp treo.\n";
const char msg_succ_rd[] PROGMEM = "[SUCCESS]: Chiều READ OK! Tra ve EOF (0 byte) chuẩn Unix.\n";
const char msg_fail_rd[] PROGMEM = "[FAILED]: Chiều READ LỖI! Node rỗng mà lại đọc ra dữ liệu?\n";
const char msg_end[]     PROGMEM = "--- VFS /dev/null TEST COMPLETED ---\n\n";
const char trash_data[]  PROGMEM = "Du lieu rac nay se bi bien mat khoi RAM vao hu vo!!!\n";

void user_process2(void) {
    int fd_null = k_sys_open("/dev/null", 0);
    k_uart_puts_P(msg_start);

    if (fd_null < 0) {
        k_uart_puts_P(msg_err_op);
        return;
    }
    k_uart_puts_P(msg_succ_op);
    int data_len = strlen_P(trash_data);
    int bytes_written = k_sys_write(fd_null, trash_data, data_len);
    
    if (bytes_written == data_len) {
        k_uart_puts_P(msg_succ_wr);
    } else {
        k_uart_puts_P(msg_fail_wr);
    }
    char rx_buffer[10];
    int bytes_read = k_sys_read(fd_null, rx_buffer, 10);
    
    if (bytes_read == 0) {
        k_uart_puts_P(msg_succ_rd);
    } else {
        k_uart_puts_P(msg_fail_rd);
    }
    k_sys_close(fd_null);
    k_uart_puts_P(msg_end);
    k_sys_exit();
}

// Định nghĩa thêm nhãn RAM tĩnh nằm trên Flash
const char msg_sys_header[] PROGMEM = "\nMPKernel Version 0.2 VostokMPK 2026.0.2\n";
const char msg_sys_tasks[]  PROGMEM = "Active Tasks: ";
const char msg_sys_ram[]    PROGMEM = "\nReal Free RAM: "; // <--- Nhãn mới ở đây!
const char msg_sys_bytes[]  PROGMEM = " Bytes";
const char msg_sys_footer[] PROGMEM = "\n-------------------------\n";

void user_process3(void) {
    struct sysinfo_data info;

    while (1) {
        int fd = k_sys_open("sysinfo", 0);
        if (fd >= 0) {
            int bytes_read = k_sys_read(fd, (char *)&info, sizeof(struct sysinfo_data));
            if (bytes_read > 0) {
                k_lock(); 
                k_uart_puts_P(msg_sys_header);
                k_uart_puts_P(msg_sys_tasks);
                k_uart_putc('0' + info.active); 
                k_uart_puts_P(msg_sys_ram);
                k_uart_put_num(info.free_ram); 
                k_uart_puts_P(msg_sys_bytes);
                k_uart_puts_P(msg_sys_footer);
                k_unlock(); 
            }
            k_sys_close(fd);
        }
        k_sys_sleep(300); 
    }
    k_sys_exit();
}
