void init_process(void) {
    // 1. Mở node thiết bị Watchdog thông qua VFS System Call của Vostok OS
    // (Ông kiểm tra xem tên hàm sys_open của ông chính xác là gì nhé, ví dụ k_sys_open hoặc sys_open)
    int wdt_fd = k_sys_open("/dev/watchdog", 0); 
    
    if (wdt_fd < 0) {
        k_uart_puts_P(PSTR("[User Init] LỖI: Không thể mở /dev/watchdog!\n"));
        while(1);
    }
    k_uart_puts_P(PSTR("[User Init] Đã mở thành công /dev/watchdog qua VFS.\n"));
    k_sys_ioctl(wdt_fd, IOCTL_WDT_ENABLE, 0);
    k_uart_puts_P(PSTR("[User Init] Đã gửi lệnh IOCTL_WDT_ENABLE. Bắt đầu đếm ngược 2s...\n"));
    k_uart_puts_P(PSTR("[User Init] Giai đoạn 1: Hệ thống chạy tốt, nuôi chó đều đặn.\n"));
    for (uint8_t i = 0; i < 6; i++) {
        k_sys_sleep(50); 
        k_sys_ioctl(wdt_fd, IOCTL_WDT_KICK, 0);
        k_uart_puts_P(PSTR("[User Init] -> Đã KICK Watchdog thành công qua VFS.\n"));
    }
    k_uart_puts_P(PSTR("[User Init] Giai đoạn 2: Cố tình treo hệ thống (Ngừng KICK)...\n"));
    k_uart_puts_P(PSTR("[User Init] Chờ đúng 2 giây, mạch phải tự RESET cứng!\n"));
    while(1) {
        // Không làm gì cả, không gọi ioctl KICK nữa
        // Ông có thể cho nháy nhẹ một con LED ở đây để quan sát nhịp treo
    }
}
