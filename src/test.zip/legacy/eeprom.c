char c_nibble_to_hex(uint8_t nibble) {
    return (nibble < 10) ? ('0' + nibble) : ('A' + (nibble - 10));
}

void init_process(void) {
    int fd_uart = k_sys_open("/dev/uart0", 0);
    int fd_eeprom = k_sys_open("/dev/eeprom", 0);
    
    const char *text_to_eeprom = "Copyright (c) Le Khanh Nam - All right reserved"; 
    char text_from_eeprom[48] = {0}; 
    uint8_t str_len = (uint8_t)strlen(text_to_eeprom);
    
    k_uart_puts_P(PSTR("[Init] Test EEPROM với chuỗi text\r\n"));
    if (fd_eeprom < 0) {
        k_panic("/dev/eeprom not found!");
    }
    k_sys_ioctl(fd_eeprom, IOCTL_EEPROM_SEEK, 250);
    k_sys_write(fd_eeprom, text_to_eeprom, str_len); 
    
    const char *msg = "<OK> Da ghi dong text vao EEPROM tai o 250.\r\n";
    k_sys_write(fd_uart, msg, strlen(msg));
    k_sys_ioctl(fd_eeprom, IOCTL_EEPROM_SEEK, 250);
    k_sys_read(fd_eeprom, text_from_eeprom, str_len);
    text_from_eeprom[str_len] = '\0'; 
    const char *answer = "Du lieu thuc te trong EEPROM (TEXT): ";
    k_sys_write(fd_uart, answer, (uint8_t)strlen(answer));
    k_sys_write(fd_uart, text_from_eeprom, str_len);
    k_sys_write(fd_uart, "\r\n", 2);
    const char *hex_title = "Du lieu thuc te trong EEPROM (HEX):  ";
    k_sys_write(fd_uart, hex_title, (uint8_t)strlen(hex_title));
    
    for (uint8_t i = 0; i < str_len; i++) {
        char hex_buf[3];
        uint8_t byte_val = (uint8_t)text_from_eeprom[i];
        hex_buf[0] = c_nibble_to_hex(byte_val >> 4);  
        hex_buf[1] = c_nibble_to_hex(byte_val & 0x0F);  
        hex_buf[2] = ' '; 
        k_sys_write(fd_uart, hex_buf, 3);
    }
    k_sys_write(fd_uart, "\r\n", 2);
    
    k_sys_sleep(500);

    k_sys_close(fd_eeprom);
    k_sys_close(fd_uart);
    k_sys_exit();
}
