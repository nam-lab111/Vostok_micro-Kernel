    int uart_fd = k_sys_open("/dev/uart0", 0);
    int servo_fd = k_sys_open("/dev/avrservo0", 0);
    if (uart_fd < 0) {
        k_uart_puts_P(PSTR("[User Process 3] [Error] Khong the mo UART qua VFS!\n"));
        while(1);
    }
    const char *msg3 = "[User Process 3] Servo da duoc dieu khien\n";
    k_sys_write(uart_fd, msg3, strlen(msg3));
    while (1) {
        k_sys_ioctl(servo_fd, IOCTL_SERVO_SET_ANGLE, 0);
        k_sys_sleep(100);
        k_sys_ioctl(servo_fd, IOCTL_SERVO_SET_ANGLE, 90);
        k_sys_sleep(100);
    }
    k_sys_sleep(30);
}
